import pandas as pd
def find_in_dictionary(str):
    file = pd.read_csv("dictionary.csv")
    keys = file["correct_word"]
    values = file["map_word"]
    for key, value in zip(keys, values):
      for v in value.split(','):
        v = v.strip()
        if str.lower().find(v.lower())!=-1:
            str = str.replace(v,key)
    return str
# if __name__ == '__main__':
#     s = find_in_dictionary("cho em hỏi học phí mis ạ")
#     print(s)