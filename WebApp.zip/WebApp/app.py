from flask import Flask, render_template, request, json, redirect
import pickle
from pre_processing_data import *
from dictionary import *
import re

app = Flask(__name__)
with open('model_cnn_49_intents.pkl', 'rb') as fp:
    cnn_45 = pickle.load(fp)
import pymysql

mydb = pymysql.connect(
    host="0.0.0.0",
    user="root",
    password="chatbot2020",
    database="chatbotdb2020"
)
print("START PROGRAM")

dict_Ner = {id: {"current_intent": None, "ok": True, "count_nums": 0, "Major_Name": None, "datetime": None,
                 "Teacher_Name": None, "Campus_Name": None, "Dept_Name": None, "Major_Mode": None, "Docs_Name": None,
                 "Scholar_Name": None,
                 "turn_Major_Name": 0, "turn_datetime": 0, "turn_Teacher_Name": 0, "turn_Campus_Name": 0,
                 "turn_Dept_Name": 0, "turn_Major_Mode": 0, "turn_Docs_Name": 0, "turn_Scholar_Name": 0}}


@app.route('/')
def default():
    return render_template("session.html")


@app.route('/process', methods=['GET', 'POST'])
def vote():
    if request.method == 'POST':
        data = {}
        teacher_name = None
        campus_name = None
        dept_name = None
        major_name = None
        year = None
        major_mode = None
        doc_name = None
        scholar_name = None
        phone_number = None
        id_user = request.get_json()['id']
        num_send = request.get_json()['num_send']
        if num_send == 0:
            dict_Ner[id_user] = {"current_intent": None, "ok": True, "count_nums": 0, "Major_Name": None,
                                 "datetime": None, "Teacher_Name": None, "Campus_Name": None, "Dept_Name": None,
                                 "Major_Mode": None, "Docs_Name": None, "Scholar_Name": None,
                                 "turn_Major_Name": 0, "turn_datetime": 0, "turn_Teacher_Name": 0,
                                 "turn_Campus_Name": 0, "turn_Dept_Name": 0, "turn_Major_Mode": 0, "turn_Docs_Name": 0,
                                 "turn_Scholar_Name": 0}
        print("ID-------------", id_user)
        rawtext = request.get_json()['text']
        message = rawtext
        check_is_exist_major = True
        if rawtext.lower().find("ngành này") != -1 or rawtext.lower().find("ngành đó") != -1 or rawtext.lower().find(
                "ngành ấy") != -1 \
                or rawtext.lower().find("ngành đấy") != -1 or rawtext.lower().find("ngành ý") != -1:
            check_is_exist_major = False
        check_is_exist_scholar = True
        if rawtext.lower().find("học bổng này") != -1 or rawtext.lower().find(
                "học bổng đó") != -1 or rawtext.lower().find(
            "học bổng ấy") != -1 \
                or rawtext.lower().find("học bổng đấy") != -1 or rawtext.lower().find("học bổng ý") != -1:
            check_is_exist_scholar = False
        check_is_exist_year = True

        if rawtext.lower().find("năm này") != -1 or rawtext.lower().find(
                "năm đó") != -1 or rawtext.lower().find(
            "năm ấy") != -1 \
                or rawtext.lower().find("năm đấy") != -1 or rawtext.lower().find("năm ý") != -1:
            check_is_exist_year = False
        check_is_exist_teacher = True
        if rawtext.lower().find("thầy ấy") != -1 or rawtext.lower().find(
                "cô ấy") != -1 or rawtext.lower().find(
            "thầy ý") != -1 \
                or rawtext.lower().find("cô ý") != -1:
            check_is_exist_teacher = False

        rawtext = find_in_dictionary(rawtext)
        print("RT", rawtext)

        try:
            phone_number = re.findall(r'[\+\(]?[0-9]{10,}', rawtext)[0]
        except:
            phone_number = None

        test_sentence = [rawtext]
        results_45 = processing_cnn_45(test_sentence, cnn_45)
        if dict_Ner[id_user]["ok"] == False and dict_Ner[id_user]["count_nums"] <= 2:
            results_45 = dict_Ner[id_user]["current_intent"]

        print("Intent", results_45)
        if phone_number is not None:
            results_45 = "Direct_advisor_request"
        results_NER = processing_NER(rawtext)
        tmp_NER = results_NER
        print("temp_NER", tmp_NER)
        print("LEN:", len(tmp_NER))
        st1 = tmp_NER[0]
        st2 = tmp_NER[1]
        text = ""
        p = '<p align="center" class="tag_{}">{} <br> {}</p>'
        ner = []
        for i in range(len(st2)):
            label = st2[i]
            word = st1[i]
            if label == "O":
                text += p.format(label, word, "")
            else:
                text += p.format(label, word, label)
                ner.append(word + " - " + label)
        for i in range(len(results_NER[1])):
            if (results_NER[1][i] == 'Major_Name'):
                if check_is_exist_major:
                    major_name = results_NER[0][i].strip()
                    major_name = major_name.replace("ngành ", "")
                    major_name = major_name.replace("nganh ", "")
                    major_name = major_name.replace("Ngành ", "")
                    major_name = major_name.replace("Nganh ", "")
                    dict_Ner[id_user]["Major_Name"] = major_name
                    dict_Ner[id_user]["turn_Major_Name"] = 0
            if (results_NER[1][i] == 'datetime'):
                if check_is_exist_year:
                    year = results_NER[0][i].strip()
                    if (len(year) > 4):
                        year = year.split(' ', 1)[1]
                        dict_Ner[id_user]["datetime"] = year
                        dict_Ner[id_user]["turn_datetime"] = 0
            if (results_NER[1][i] == 'Teacher_Name'):
                if check_is_exist_teacher:
                    teacher_name = results_NER[0][i].strip()
                    dict_Ner[id_user]["Teacher_Name"] = teacher_name
                    dict_Ner[id_user]["turn_Teacher_Name"] = 0
            if (results_NER[1][i] == 'Campus_Name' or results_NER[1][i] == 'Dept_Name'):
                campus_name = results_NER[0][i].strip()
                campus_name = campus_name.replace("cs ", "")
                campus_name = campus_name.replace("cơ sở ", "")
                campus_name = campus_name.replace("CS", "")
                campus_name = campus_name.replace("Cơ Sở", "")
                dict_Ner[id_user]["Campus_Name"] = campus_name
                dict_Ner[id_user]["turn_Campus_Name"] = 0
            if (results_NER[1][i] == 'Dept_Name'):
                dept_name = results_NER[0][i].strip()
                dict_Ner[id_user]["Dept_Name"] = dept_name
                dict_Ner[id_user]["turn_Dept_Name"] = 0
            if (results_NER[1][i] == 'Major_Mode'):
                major_mode = results_NER[1][i].strip()
                dict_Ner[id_user]["Major_Mode"] = major_mode
                dict_Ner[id_user]["turn_Major_Mode"] = 0
            if (results_NER[1][i] == 'Docs_Name'):
                doc_name = results_NER[0][i].strip()
                doc_name = doc_name.replace("giay ", "")
                doc_name = doc_name.replace("giấy ", "")
                doc_name = doc_name.replace("Giấy ", "")
                doc_name = doc_name.replace("Giây ", "")
                dict_Ner[id_user]["Docs_Name"] = doc_name
                dict_Ner[id_user]["turn_Docs_Name"] = 0

            if (results_NER[1][i] == 'Scholar_Name'):
                if check_is_exist_scholar:
                    scholar_name = results_NER[0][i].strip()
                    dict_Ner[id_user]["Scholar_Name"] = scholar_name
                    dict_Ner[id_user]["turn_Scholar_Name"] = 0

        dict_Ner[id_user]["turn_Major_Name"], dict_Ner[id_user]["turn_datetime"], dict_Ner[id_user][
            "turn_Teacher_Name"], dict_Ner[id_user]["turn_Campus_Name"], dict_Ner[id_user]["turn_Dept_Name"], \
        dict_Ner[id_user]["turn_Major_Mode"], dict_Ner[id_user]["turn_Docs_Name"], dict_Ner[id_user][
            "turn_Scholar_Name"] = get_turn(dict_Ner[id_user]["turn_Major_Name"], dict_Ner[id_user]["turn_datetime"],
                                            dict_Ner[id_user]["turn_Teacher_Name"],
                                            dict_Ner[id_user]["turn_Campus_Name"], dict_Ner[id_user]["turn_Dept_Name"],
                                            dict_Ner[id_user]["turn_Major_Mode"], dict_Ner[id_user]["turn_Docs_Name"],
                                            dict_Ner[id_user]["turn_Scholar_Name"], major_name, year, teacher_name,
                                            campus_name, dept_name, major_mode, doc_name, scholar_name)
        if results_45 == "Basic_point":
            intent = "điểm chuẩn"
            if dict_Ner[id_user]["datetime"] is None and dict_Ner[id_user]["Major_Name"] is None:
                answer = random_MajorName_Answer(intent)
                dict_Ner[id_user]["ok"] = False
                dict_Ner[id_user]["count_nums"] += 1
                dict_Ner[id_user]["current_intent"] = results_45
            elif (dict_Ner[id_user]["datetime"] is None and dict_Ner[id_user]["Major_Name"] is not None):
                answer = random_KYear_Answer(intent)
                dict_Ner[id_user]["ok"] = False
                dict_Ner[id_user]["count_nums"] += 1
                dict_Ner[id_user]["current_intent"] = results_45
            elif (dict_Ner[id_user]["datetime"] is not None and dict_Ner[id_user]["Major_Name"] is None):
                if (int(dict_Ner[id_user]["datetime"]) > 2020):
                    answer = "Rất tiếc! Hiện chưa có điểm chuẩn của " + dict_Ner[id_user][
                        "datetime"] + ".Bạn có muốn hỏi năm khác không ạ?"
                    dict_Ner[id_user]["ok"] = False
                    dict_Ner[id_user]["count_nums"] += 1
                    dict_Ner[id_user]["current_intent"] = results_45
                else:
                    answer = random_MajorName_Answer(intent)
                    dict_Ner[id_user]["ok"] = False
                    dict_Ner[id_user]["count_nums"] += 1
                    dict_Ner[id_user]["current_intent"] = results_45
            else:
                if (int(dict_Ner[id_user]["datetime"]) > 2020):
                    answer = "Rất tiếc! Hiện chưa có điểm chuẩn của " + dict_Ner[id_user][
                        "datetime"] + ".Bạn có muốn hỏi năm khác không ạ?"
                    dict_Ner[id_user]["ok"] = False
                    dict_Ner[id_user]["count_nums"] += 1
                    dict_Ner[id_user]["current_intent"] = results_45
                else:
                    _, nums = read_Basic_point(mydb, dict_Ner[id_user]["Major_Name"], dict_Ner[id_user]["datetime"])
                    if (0 < nums <= 1):
                        answer = read_Basic_point(mydb, dict_Ner[id_user]["Major_Name"], dict_Ner[id_user]["datetime"])[
                            0]
                        dict_Ner[id_user]["ok"] = True
                        dict_Ner[id_user]["count_nums"] = 0
                    else:
                        answer = "Ngành này không có trong danh sách đào tạo của Khoa hoặc chưa cập nhật điểm chuẩn, bạn vui lòng liên hệ sau nhé!"
                        dict_Ner[id_user]["ok"] = False
                        dict_Ner[id_user]["count_nums"] += 1
                        dict_Ner[id_user]["current_intent"] = results_45

        elif results_45 == "Major_Code":
            intent = "mã ngành"
            if dict_Ner[id_user]["Major_Name"] is None:
                answer = random_MajorName_Answer(intent)
                dict_Ner[id_user]["ok"] = False
                dict_Ner[id_user]["count_nums"] += 1
                dict_Ner[id_user]["current_intent"] = results_45
            else:
                answer = read_Major_Infor(mydb, dict_Ner[id_user]["Major_Name"])
                if answer != "":
                    answer = read_Major_Infor(mydb, dict_Ner[id_user]["Major_Name"])
                    dict_Ner[id_user]["ok"] = True
                    dict_Ner[id_user]["count_nums"] = 0
                else:
                    answer = random_not_found_major(dict_Ner[id_user]["Major_Name"])
                    dict_Ner[id_user]["ok"] = False
                    dict_Ner[id_user]["count_nums"] += 1
                    dict_Ner[id_user]["current_intent"] = results_45

        elif results_45 == "contact_point" and dict_Ner[id_user]["Campus_Name"] is not None and dict_Ner[id_user][
            "Teacher_Name"] is None:
            _, nums = read_Contact_point_Dept(mydb, dict_Ner[id_user]["Campus_Name"])
            if (0 < nums <= 1):
                answer = read_Contact_point_Dept(mydb, dict_Ner[id_user]["Campus_Name"])[0]
                dict_Ner[id_user]["ok"] = True
                dict_Ner[id_user]["count_nums"] = 0
            else:
                answer = "Xin lỗi " + dict_Ner[id_user][
                    "Campus_Name"] + " bạn đang hỏi không có trong danh sách phòng/ban của Khoa ạ!"
                dict_Ner[id_user]["ok"] = False
                dict_Ner[id_user]["count_nums"] += 1
                dict_Ner[id_user]["current_intent"] = results_45

        elif results_45 == "contact_point" and dict_Ner[id_user]["Campus_Name"] is None and dict_Ner[id_user][
            "Teacher_Name"] is None:
            answer = "Xin lỗi mình chưa hiểu bạn muốn liên hệ về vấn đề gì ạ"
            dict_Ner[id_user]["ok"] = False
            dict_Ner[id_user]["count_nums"] += 1
            dict_Ner[id_user]["current_intent"] = results_45

        elif results_45 == "contact_point" and dict_Ner[id_user]["Teacher_Name"] is not None:
            _, nums, teachers = read_Contact_point_Teacher(mydb, dict_Ner[id_user]["Teacher_Name"],
                                                           dict_Ner[id_user]["Dept_Name"])
            if (0 < nums <= 1):
                answer = \
                read_Contact_point_Teacher(mydb, dict_Ner[id_user]["Teacher_Name"], dict_Ner[id_user]["Dept_Name"])[0]
                dict_Ner[id_user]["ok"] = True
                dict_Ner[id_user]["count_nums"] = 0
            elif nums > 1:
                answer = random_TeacherName_Answer(dict_Ner[id_user]["Teacher_Name"], nums, teachers)
                dict_Ner[id_user]["ok"] = False
                dict_Ner[id_user]["count_nums"] += 1
                dict_Ner[id_user]["current_intent"] = results_45
            else:
                answer = "Xin lỗi, Khoa không có thông tin " + dict_Ner[id_user]["Teacher_Name"] + " mà bạn muốn hỏi!"
                dict_Ner[id_user]["ok"] = False
                dict_Ner[id_user]["count_nums"] += 1
                dict_Ner[id_user]["current_intent"] = results_45

        elif results_45 == "Major_Fee":
            intent = "học phí"
            if dict_Ner[id_user]["Major_Name"] is None:
                answer = random_MajorName_Answer(intent)
                dict_Ner[id_user]["ok"] = False
                dict_Ner[id_user]["count_nums"] += 1
                dict_Ner[id_user]["current_intent"] = results_45
            else:
                answer = read_Major_Fee(mydb, dict_Ner[id_user]["Major_Name"])
                if answer != "":
                    answer = read_Major_Fee(mydb, dict_Ner[id_user]["Major_Name"])
                    dict_Ner[id_user]["ok"] = True
                    dict_Ner[id_user]["count_nums"] = 0
                else:
                    answer = random_not_found_major(dict_Ner[id_user]["Major_Name"])
                    dict_Ner[id_user]["ok"] = False
                    dict_Ner[id_user]["count_nums"] += 1
                    dict_Ner[id_user]["current_intent"] = results_45

        elif results_45 == "Credit_Fee":
            intent = "học phí (tín chỉ)"
            if dict_Ner[id_user]["Major_Name"] is None:
                answer = random_MajorName_Answer(intent)
                dict_Ner[id_user]["ok"] = False
                dict_Ner[id_user]["count_nums"] += 1
                dict_Ner[id_user]["current_intent"] = results_45
            else:
                answer = read_Credit_Fee(mydb, dict_Ner[id_user]["Major_Name"])
                if answer != "":
                    answer = read_Credit_Fee(mydb, dict_Ner[id_user]["Major_Name"])
                    dict_Ner[id_user]["ok"] = True
                    dict_Ner[id_user]["count_nums"] = 0
                else:
                    answer = random_not_found_major(dict_Ner[id_user]["Major_Name"])
                    dict_Ner[id_user]["ok"] = False
                    dict_Ner[id_user]["count_nums"] += 1
                    dict_Ner[id_user]["current_intent"] = results_45

        elif results_45 == "Major_Description":
            intent = "mô tả ngành"
            if dict_Ner[id_user]["Major_Name"] is None:
                answer = random_MajorName_Answer(intent)
                dict_Ner[id_user]["ok"] = False
                dict_Ner[id_user]["count_nums"] += 1
                dict_Ner[id_user]["current_intent"] = results_45
            else:
                answer = read_Major_Description(mydb, dict_Ner[id_user]["Major_Name"])
                if answer != "":
                    answer = read_Major_Description(mydb, dict_Ner[id_user]["Major_Name"])
                    dict_Ner[id_user]["ok"] = True
                    dict_Ner[id_user]["count_nums"] = 0
                else:
                    answer = random_not_found_major(dict_Ner[id_user]["Major_Name"])
                    dict_Ner[id_user]["ok"] = False
                    dict_Ner[id_user]["count_nums"] += 1
                    dict_Ner[id_user]["current_intent"] = results_45

        elif results_45 == "Issued_by":
            intent = "cấp bằng"
            if dict_Ner[id_user]["Major_Name"] is None:
                answer = random_MajorName_Answer(intent)
                dict_Ner[id_user]["ok"] = False
                dict_Ner[id_user]["count_nums"] += 1
                dict_Ner[id_user]["current_intent"] = results_45
            else:
                answer = read_Issued_By(mydb, dict_Ner[id_user]["Major_Name"])
                if answer != "":
                    answer = read_Issued_By(mydb, dict_Ner[id_user]["Major_Name"])
                    dict_Ner[id_user]["ok"] = True
                    dict_Ner[id_user]["count_nums"] = 0
                else:
                    answer = random_not_found_major(dict_Ner[id_user]["Major_Name"])
                    dict_Ner[id_user]["ok"] = False
                    dict_Ner[id_user]["count_nums"] += 1
                    dict_Ner[id_user]["current_intent"] = results_45

        elif results_45 == "Mode_of_Study":
            intent = "chế độ học tập"
            if dict_Ner[id_user]["Major_Mode"] is None:
                answer = random_Program_Answer(intent)
                dict_Ner[id_user]["ok"] = False
                dict_Ner[id_user]["count_nums"] += 1
                dict_Ner[id_user]["current_intent"] = results_45
            else:
                ans = read_Mode_of_Study(mydb, dict_Ner[id_user]["Major_Mode"])
                if (ans != ""):
                    answer = ans
                    dict_Ner[id_user]["ok"] = True
                    dict_Ner[id_user]["count_nums"] = 0
                else:
                    answer = "Chương trình này chưa cập nhật thông tin, bạn vui lòng liên hệ sau nhé"
                    dict_Ner[id_user]["ok"] = False
                    dict_Ner[id_user]["count_nums"] += 1
                    dict_Ner[id_user]["current_intent"] = results_45

        elif results_45 == "Major_training_time":
            intent = "thời gian đào tạo"
            if dict_Ner[id_user]["Major_Name"] is None:
                answer = random_MajorName_Answer(intent)
                dict_Ner[id_user]["ok"] = False
                dict_Ner[id_user]["count_nums"] += 1
                dict_Ner[id_user]["current_intent"] = results_45
            else:
                ans = read_Major_training_time(mydb, dict_Ner[id_user]["Major_Name"])
                if (ans != ""):
                    answer = ans
                    dict_Ner[id_user]["ok"] = True
                    dict_Ner[id_user]["count_nums"] = 0
                else:
                    answer = random_not_found_major(dict_Ner[id_user]["Major_Name"])
                    dict_Ner[id_user]["ok"] = False
                    dict_Ner[id_user]["count_nums"] += 1
                    dict_Ner[id_user]["current_intent"] = results_45

        elif results_45 == "Job_Opportunities":
            intent = "cơ hội nghề nghiệp"
            if dict_Ner[id_user]["Major_Name"] is None:
                answer = random_MajorName_Answer(intent)
                dict_Ner[id_user]["ok"] = False
                dict_Ner[id_user]["count_nums"] += 1
                dict_Ner[id_user]["current_intent"] = results_45
            else:
                ans = read_Job_Opportunities(mydb, dict_Ner[id_user]["Major_Name"])
                if (ans != ""):
                    answer = ans
                    dict_Ner[id_user]["ok"] = True
                    dict_Ner[id_user]["count_nums"] = 0
                else:
                    answer = random_not_found_major(dict_Ner[id_user]["Major_Name"])
                    dict_Ner[id_user]["ok"] = False
                    dict_Ner[id_user]["count_nums"] += 1
                    dict_Ner[id_user]["current_intent"] = results_45

        elif results_45 == "Enroll_Docs" or results_45 == "Enroll_Procedure":
            if dict_Ner[id_user]["Docs_Name"] is None:
                answer = random_DocsName_Answer()
                dict_Ner[id_user]["ok"] = False
                dict_Ner[id_user]["count_nums"] += 1
                dict_Ner[id_user]["current_intent"] = results_45
            else:
                ans = read_Enroll_Docs(mydb, dict_Ner[id_user]["Docs_Name"])
                if (ans != ""):
                    answer = ans
                    dict_Ner[id_user]["ok"] = True
                    dict_Ner[id_user]["count_nums"] = 0
                else:
                    answer = "Hiện tại chưa cập nhật thông tin, bạn vui lòng liên hệ sau nhé"
                    dict_Ner[id_user]["ok"] = False
                    dict_Ner[id_user]["count_nums"] += 1
                    dict_Ner[id_user]["current_intent"] = results_45

        elif results_45 == "Enroll_Location" or results_45 == "Enroll_Procedure":
            answer = "Địa điểm nhập học là Nhà C, Làng sinh viên Hacinco, số 79 Ngụy Như Kon Tum, Nhân Chính, Thanh Xuân, Hà Nội."

        elif results_45 == "Curriculumn":
            intent = "khung chương trình đào tạo"
            if dict_Ner[id_user]["Major_Name"] is None:
                answer = random_MajorName_Answer(intent)
                dict_Ner[id_user]["ok"] = False
                dict_Ner[id_user]["count_nums"] += 1
                dict_Ner[id_user]["current_intent"] = results_45
            else:
                ans = read_NoCredit_Major(mydb, dict_Ner[id_user]["Major_Name"])
                if (ans != ""):
                    answer = ans
                    dict_Ner[id_user]["ok"] = True
                    dict_Ner[id_user]["count_nums"] = 0
                else:
                    answer = random_not_found_major(dict_Ner[id_user]["Major_Name"])
                    dict_Ner[id_user]["ok"] = False
                    dict_Ner[id_user]["count_nums"] += 1
                    dict_Ner[id_user]["current_intent"] = results_45

        elif results_45 == "Greetings ":
            answer = random_Greeting_Answer()
            dict_Ner[id_user]["ok"] = True
            dict_Ner[id_user]["count_nums"] = 0

        elif results_45 == "Bye":
            answer = random_Bye_Answer()
            dict_Ner[id_user]["ok"] = True
            dict_Ner[id_user]["count_nums"] = 0
        elif results_45 == "Agree":
            answer = random_Agree_Answer()
            dict_Ner[id_user]["ok"] = True
            dict_Ner[id_user]["count_nums"] = 0
        elif results_45 == "Scholar_Value":
            intent = "giá trị học bổng"
            if dict_Ner[id_user]["Scholar_Name"] is None:
                answer = random_Scholar_Answer(intent)
                dict_Ner[id_user]["ok"] = False
                dict_Ner[id_user]["count_nums"] += 1
                dict_Ner[id_user]["current_intent"] = results_45
            else:
                answer = read_Scholar_Value(mydb, dict_Ner[id_user]["Scholar_Name"])
                if answer != "":
                    answer = read_Scholar_Value(mydb, dict_Ner[id_user]["Scholar_Name"])
                    dict_Ner[id_user]["ok"] = True
                    dict_Ner[id_user]["count_nums"] = 0
                else:
                    answer = random_not_found_scholar(dict_Ner[id_user]["Scholar_Name"])
                    dict_Ner[id_user]["ok"] = False
                    dict_Ner[id_user]["count_nums"] += 1
                    dict_Ner[id_user]["current_intent"] = results_45

        elif results_45 == "Scholar_Type":
            if dict_Ner[id_user]["Scholar_Name"] is None:
                answer = read_Scholar_Type_No_name()
                dict_Ner[id_user]["ok"] = False
                dict_Ner[id_user]["count_nums"] += 1
                dict_Ner[id_user]["current_intent"] = results_45
            else:
                answer = read_Scholar_Type(mydb, dict_Ner[id_user]["Scholar_Name"])
                if answer != "":
                    answer = read_Scholar_Type(mydb, dict_Ner[id_user]["Scholar_Name"])
                    dict_Ner[id_user]["ok"] = True
                    dict_Ner[id_user]["count_nums"] = 0
                else:
                    answer = random_not_found_scholar(dict_Ner[id_user]["Scholar_Name"])
                    dict_Ner[id_user]["ok"] = False
                    dict_Ner[id_user]["count_nums"] += 1
                    dict_Ner[id_user]["current_intent"] = results_45

        elif results_45 == "School_Location" or results_45 == "Campus_Info" or results_45 == "Study_Location":
            answer = read_School_Location()
            dict_Ner[id_user]["ok"] = True
            dict_Ner[id_user]["count_nums"] = 0

        elif results_45 == "Admission_Type":
            answer = read_Admission_Type()
            dict_Ner[id_user]["ok"] = True
            dict_Ner[id_user]["count_nums"] = 0

        elif results_45 == "Direct_Offer":
            answer = read_Direct_Offer()
            dict_Ner[id_user]["ok"] = True
            dict_Ner[id_user]["count_nums"] = 0

        elif results_45 == "Trans_Opportunity":
            answer = read_Trans_Opportunity()
            dict_Ner[id_user]["ok"] = True
            dict_Ner[id_user]["count_nums"] = 0

        elif results_45 == "Establishment_Time":
            answer = read_Establishment_Time()
            dict_Ner[id_user]["ok"] = True
            dict_Ner[id_user]["count_nums"] = 0

        elif results_45 == "School_Organization":
            answer = read_School_Organization()
            dict_Ner[id_user]["ok"] = True
            dict_Ner[id_user]["count_nums"] = 0
        elif results_45 == "School_mission":
            answer = read_School_Mission()
            dict_Ner[id_user]["ok"] = True
            dict_Ner[id_user]["count_nums"] = 0



        elif results_45 == "research_direction":
            if dict_Ner[id_user]["Teacher_Name"] is None:
                answer = "Bạn đang quan tâm về hướng nghiên cứu của thầy, cô nào vậy ạ!"
                dict_Ner[id_user]["ok"] = False
                dict_Ner[id_user]["count_nums"] += 1
                dict_Ner[id_user]["current_intent"] = results_45
            else:
                _, nums = read_Research_Direction(mydb, dict_Ner[id_user]["Teacher_Name"])
                if 0 < nums <= 1:
                    answer = read_Research_Direction(mydb, dict_Ner[id_user]["Teacher_Name"])
                    dict_Ner[id_user]["ok"] = True
                    dict_Ner[id_user]["count_nums"] = 0
                elif nums > 1:
                    answer = "Hiện khoa đang có " + str(
                        nums) + " " + dict_Ner[id_user]["Teacher_Name"] + ". Bạn muốn hỏi hướng nghiên cứu của " + \
                             dict_Ner[id_user]["Teacher_Name"] + " nào ạ ?"
                    dict_Ner[id_user]["ok"] = False
                    dict_Ner[id_user]["count_nums"] += 1
                    dict_Ner[id_user]["current_intent"] = results_45
                else:
                    answer = "Hiện tại Khoa chưa cập nhật thông tin nghiên cứu khoa học của thầy, cô bạn cần. Bạn hỏi lại sau nhé!"
                    dict_Ner[id_user]["ok"] = False
                    dict_Ner[id_user]["count_nums"] += 1
                    dict_Ner[id_user]["current_intent"] = results_45


        elif results_45 == "Planned_Figure":
            intent = "chỉ tiêu tuyển sinh"
            if dict_Ner[id_user]["Major_Name"] is None and dict_Ner[id_user]["datetime"] is None:
                answer = random_MajorName_Answer(intent)
                dict_Ner[id_user]["ok"] = False
                dict_Ner[id_user]["count_nums"] += 1
                dict_Ner[id_user]["current_intent"] = results_45
            elif dict_Ner[id_user]["Major_Name"] is None and dict_Ner[id_user]["datetime"] is not None:
                if int(dict_Ner[id_user]["datetime"]) > 2020:
                    answer = "Rất tiếc! Hiện chưa có chỉ tiêu tuyển sinh của " + dict_Ner[id_user][
                        "datetime"] + ".Bạn có muốn hỏi năm khác không ạ?"
                    dict_Ner[id_user]["ok"] = False
                    dict_Ner[id_user]["count_nums"] += 1
                    dict_Ner[id_user]["current_intent"] = results_45
                else:
                    answer = random_MajorName_Answer(intent)
                    dict_Ner[id_user]["ok"] = False
                    dict_Ner[id_user]["count_nums"] += 1
                    dict_Ner[id_user]["current_intent"] = results_45
            elif dict_Ner[id_user]["Major_Name"] is not None and dict_Ner[id_user]["datetime"] is None:
                answer = random_KYear_Answer(intent)
                dict_Ner[id_user]["ok"] = False
                dict_Ner[id_user]["count_nums"] += 1
                dict_Ner[id_user]["current_intent"] = results_45
            else:
                if int(dict_Ner[id_user]["datetime"]) > 2020:
                    answer = "Rất tiếc! Hiện chưa có chỉ tiêu tuyển sinh của " + dict_Ner[id_user][
                        "datetime"] + ".Bạn có muốn hỏi năm khác không ạ?"
                    dict_Ner[id_user]["ok"] = False
                    dict_Ner[id_user]["count_nums"] += 1
                    dict_Ner[id_user]["current_intent"] = results_45
                else:
                    answer = read_Planned_Figure(mydb, dict_Ner[id_user]["Major_Name"], dict_Ner[id_user]["datetime"])
                    if answer != "":
                        answer = read_Planned_Figure(mydb, dict_Ner[id_user]["Major_Name"],
                                                     dict_Ner[id_user]["datetime"])
                        dict_Ner[id_user]["ok"] = True
                        dict_Ner[id_user]["count_nums"] = 0
                    else:
                        answer = random_not_found_major(dict_Ner[id_user]["Major_Name"])
                        dict_Ner[id_user]["ok"] = False
                        dict_Ner[id_user]["count_nums"] += 1
                        dict_Ner[id_user]["current_intent"] = results_45

        elif results_45 == "Scholar_quota":
            answer = "Tùy mỗi kỳ và số lượng sinh viên đăng ký sẽ thay đổi theo từng loại học bổng. Số lượng học bổng sẽ được công bố khi hội đồng xét duyệt họp ạ!"
            dict_Ner[id_user]["ok"] = True
            dict_Ner[id_user]["count_nums"] = 0

        elif results_45 == "Direct_advisor_request":
            if phone_number is None:
                answer = random_Direct_Resquest_PhoneNumber()
                dict_Ner[id_user]["ok"] = False
                dict_Ner[id_user]["count_nums"] += 1
                dict_Ner[id_user]["current_intent"] = results_45
            else:
                answer = random_Direct_Resquest_Answer(phone_number)
                dict_Ner[id_user]["ok"] = True
                dict_Ner[id_user]["count_nums"] = 0
        elif results_45 == "Training_majors_at_IS":
            answer = "Khoa Quốc Tế -ĐHQG Hà Nội hiện đang đào tạo các ngành trình độ Đại học sau: Kinh doanh quốc tế; Kế toán, Phân tích và Kiểm toán; Hệ thống thông tin quản lý;" \
                     "Tin học và Kỹ thuật máy tính; Phân tích dữ liệu kinh doanh; Khoa học quản lý; Quản trị khách sạn thể thao và du lịch; Kế toán và Tài chính;" \
                     "Ngôn ngữ Anh; Ngôn ngữ Hàn; Ngôn ngữ Nhật; Marketing (song bằng); Quản lý (song bằng)."

        elif results_45 == "Other":
            answer = random_Other_Answer()
            dict_Ner[id_user]["ok"] = True
            dict_Ner[id_user]["count_nums"] = 0
        elif results_45 == "Info_provide":
            answer = random_Other_Answer()
            dict_Ner[id_user]["ok"] = True
            dict_Ner[id_user]["count_nums"] = 0
        elif results_45 != "Basic_point" and results_45 != "Major_Code" and results_45 != "contact_point" and results_45 != "Major_Fee" \
                and results_45 != "Credit_Fee" and results_45 != "Major_Description" and results_45 != "Mode_of_Study" and results_45 != "Major_training_time" \
                and results_45 != "Job_Opportunities" and results_45 != "Enroll_Docs" and results_45 != "Enroll_Procedure" and results_45 != "Enroll_Location" \
                and results_45 != "Curriculumn" and results_45 != "Greetings" and results_45 != "Bye" and results_45 != "Agree" and results_45 != "Scholar_Value" \
                and results_45 != "Scholar_Type" and results_45 != "School_Location" and results_45 != "Campus_Info" and results_45 != "Study_Location" \
                and results_45 != "Establishment_Time" and results_45 != "School_Organization" and results_45 != "research_direction" and results_45 != "Planned_Figure" \
                and results_45 != "Scholar_quota" and results_45 != "Other" and results_45 != "Info_provide" and results_45 != "Direct_advisor_request" and results_45 != "Training_majors_at_IS" \
                and results_45 != "Admission_Type" and results_45 != "Direct_Offer" and results_45 != "Trans_Opportunity" and results_45 != "Issued_by":
            answer = random_Out_Area_Answer()
        if check_is_exist_major == False:
            dict_Ner[id_user]["turn_Major_Name"] = 0
        if check_is_exist_year == False:
            dict_Ner[id_user]["turn_datetime"] = 0
        if check_is_exist_scholar == False:
            dict_Ner[id_user]["turn_Scholar_Name"] = 0
        if check_is_exist_teacher == False:
            dict_Ner[id_user]["turn_Teacher_Name"] = 0
        if dict_Ner[id_user]["turn_Major_Name"] >= 3:
            dict_Ner[id_user]["Major_Name"] = None
        if dict_Ner[id_user]["turn_datetime"] >= 3:
            dict_Ner[id_user]["datetime"] = None
        if dict_Ner[id_user]["turn_Teacher_Name"] >= 3:
            dict_Ner[id_user]["Teacher_Name"] = None
        if dict_Ner[id_user]["turn_Campus_Name"] >= 3:
            dict_Ner[id_user]["Campus_Name"] = None
        if dict_Ner[id_user]["turn_Dept_Name"] >= 3:
            dict_Ner[id_user]["Dept_Name"] = None
        if dict_Ner[id_user]["turn_Major_Mode"] >= 3:
            dict_Ner[id_user]["Major_Mode"] = None
        if dict_Ner[id_user]["turn_Docs_Name"] >= 3:
            dict_Ner[id_user]["Docs_Name"] = None
        if dict_Ner[id_user]["turn_Scholar_Name"] >= 3:
            dict_Ner[id_user]["Scholar_Name"] = None

        print("DICT-NER", dict_Ner[id_user])
        data = {
            'Message': rawtext,
            'Intent': results_45,
            'NER': str(ner),
            'Respond': str(answer)
        }
        with open('log_file.json', 'a', encoding='utf8') as outfile:
            json.dump(data, outfile, ensure_ascii=False, indent=2)
        text = {'text': message, 'results_45': results_45, 'answer': answer,
                'results_NER': ner, "num_send": num_send}
    return json.dumps({'success': True, 'text_tagged': text}), 200, {'Content-Type': 'application/json; charset=UTF-8'}


def main():
    app.run(host='0.0.0.0', threaded=False, port=8080)

if __name__ == '__main__':
    main()

#if __name__ == '__main__':
#    app.run(host='0.0.0.0', threaded=False, port=8080)