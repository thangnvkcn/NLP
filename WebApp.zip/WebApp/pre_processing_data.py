
import random
from underthesea import pos_tag
from keras.preprocessing.sequence import pad_sequences
from underthesea import word_tokenize
import pandas as pd
import numpy as np
from keras.preprocessing.text import Tokenizer
from pyvi import ViTokenizer
import pickle

NUM_WORDS = 1500


def getData(file_path):
    data = pd.read_csv(file_path)
    return data


def txtTokenizer(data):
    sentences = data.sentence
    tokenizer = Tokenizer(num_words=NUM_WORDS, filters='!"#$%&()*+,-./:;<=>?@[\\]^_`{|}~\t\n\'',
                          lower=True)
    tokenizer.fit_on_texts(sentences)
    word_index = tokenizer.word_index
    return tokenizer, word_index


def processing_cnn_45(test_sentence, model):
    file_path = 'data_intent_49_update.csv'
    data = getData(file_path)
    intents = data.intent.unique()
    tokenizer, word_index = txtTokenizer(data)
    X_test = tokenizer.texts_to_sequences(test_sentence)
    X_test = pad_sequences(X_test, maxlen=256, dtype="long", truncating="post", padding="post")
    import time
    start_time = time.time()
    predict = model.predict(X_test)
    predict = predict.argmax(axis=-1)
    end_time = time.time()
    print('total run-time: %f ms' % ((end_time - start_time) * 1000))
    for indx, label in enumerate(intents):
        if (predict == indx):
            intent = label
    return intent


def unique(list1):
    unique_list = []
    for x in list1:
        if x not in unique_list:
            unique_list.append(x)
    for x in unique_list:
        return x


def word2features(sent, i):
    word = sent[i][0]
    postag = sent[i][1]

    features = {
        'bias': 1.0,
        'word.lower()': word.lower(),
        'word[-3:]': word[-3:],
        'word[-2:]': word[-2:],
        'word.isupper()': word.isupper(),
        'word.istitle()': word.istitle(),
        'word.isdigit()': word.isdigit(),
        'postag': postag,
        'postag[:2]': postag[:2],
    }
    if i > 0:
        word1 = sent[i - 1][0]
        postag1 = sent[i - 1][1]
        features.update({
            '-1:word.lower()': word1.lower(),
            '-1:word.istitle()': word1.istitle(),
            '-1:word.isupper()': word1.isupper(),
            '-1:postag': postag1,
            '-1:postag[:2]': postag1[:2],
        })
    else:
        features['BOS'] = True

    if i < len(sent) - 1:
        word1 = sent[i + 1][0]
        postag1 = sent[i + 1][1]
        features.update({
            '+1:word.lower()': word1.lower(),
            '+1:word.istitle()': word1.istitle(),
            '+1:word.isupper()': word1.isupper(),
            '+1:postag': postag1,
            '+1:postag[:2]': postag1[:2],
        })
    else:
        features['EOS'] = True

    return features


def sent2features(sent):
    return [word2features(sent, i) for i in range(len(sent))]


def processing_NER(sentence):
    sentence = ViTokenizer.tokenize(sentence)
    pos = pos_tag(sentence)
    sentence = word_tokenize(sentence)
    X = [sent2features(pos)]
    import time
    start_time = time.time()
    with open('model_CRF_NER.pkl', 'rb') as fp:
        crf = pickle.load(fp)
    pred = crf.predict(X)
    pred = np.array(pred)
    pred = pred.flatten()
    print(pred)
    end_time = time.time()
    print('total run-time: %f ms' % ((end_time - start_time) * 1000))
    # Product perform by upper word
    sentence2string = ''
    words = []
    tag = []
    i = 0
    if (len(pred) >= 2):
        for word, label in list(zip(sentence, pred)):
            if label[0] == 'B':
                sentence2string = ''
                sentence2string += (word.replace('_', " "))
                tag.append(label[2:])
            if label[0] == 'I' and word != ',':
                sentence2string += (' ' + word.replace('_', " "))
            if label[0] == 'I' and word == ',':
                sentence2string += (word.replace('_', " "))
            if label[0] == 'I' and (i + 1 == len(pred)):
                words.append(sentence2string)
            if ((i + 1) > len(pred)):
                break
            if ((i + 1) < len(pred)):
                if label[0] == 'I' and pred[i + 1][0] == 'O':
                    words.append(sentence2string)
                if label[0] == 'I' and pred[i + 1][0] == 'B':
                    words.append(sentence2string)
                if label[0] == 'B' and pred[i + 1][0] == 'O':
                    words.append(sentence2string)
                if label[0] == 'B' and pred[i + 1][0] == 'B':
                    words.append(sentence2string)
            if ((i + 1) == len(pred)):
                if label[0] == 'B':
                    words.append(sentence2string)
            i = i + 1
        return words, tag
    if (len(pred) < 2):
        for word, label in list(zip(sentence, pred)):
            if label[0] == 'B':
                tag = []
                sentence2string = ''
                sentence2string += (word + ' ')
                tag.append(label[2:])
                words.append(sentence2string)
        return words, tag


def read_Basic_point(conn, major_name, year):
    print(major_name)
    print("Read")
    answer = ""
    nums = 0
    cursor = conn.cursor()
    if major_name is not None and year is not None:
        try:
            cursor.execute(
                f"select DiemChuan,TenNganh,Nam from basic_point where TenNganh LIKE N'%{major_name}%' AND Nam LIKE {year};")
            nums = 0
            for row in cursor:
                nums = nums + 1
                answer = f'Điểm chuẩn ngành {row[1]} năm {row[2]} là {row[0]}'
        except:
            answer = random_Other_Answer()
    return answer, nums


def read_Research_Direction(conn, teacher_name):
    answer = ""
    teacher_name_tmp = teacher_name.replace("thầy ", "")
    teacher_name_tmp = teacher_name_tmp.replace("cô ", "")
    teacher_name_tmp = teacher_name_tmp.replace("thây ", "")
    teacher_name_tmp = teacher_name_tmp.replace("thày ", "")
    teacher_name_tmp = teacher_name_tmp.replace("co ", "")
    teacher_name_tmp = teacher_name_tmp.replace("Thầy ", "")
    teacher_name_tmp = teacher_name_tmp.replace("Cô ", "")
    teacher_name_tmp = teacher_name_tmp.replace("Thây ", "")
    teacher_name_tmp = teacher_name_tmp.replace("Thày ", "")
    teacher_name_tmp = teacher_name_tmp.replace("Co ", "")

    cursor = conn.cursor()
    try:
        cursor.execute(
            f"select teacher_infor,subject,direction,major_name,scientific_research from research_direction where teacher_name LIKE N'%{teacher_name_tmp}%';")
        nums = 0
        for row in cursor:
            nums += 1
            answer = f'Thông tin nghiên cứu của {teacher_name} là: Thông tin giảng viên: {row[0]} - Bộ môn: {row[1]} - Hướng nghiên cứu: {row[2]} - Chuyên ngành: {row[3]} - Công trình khoa học đã công bố: {row[4]}'
    except:
        answer = random_Other_Answer()
    return answer, nums


def read_Major_Infor(conn, tennganh):
    print("Read")
    answer = ""
    cursor = conn.cursor()
    try:
        cursor.execute(f"select MaNganh,TenNganh from major_infor where TenNganh LIKE N'%{tennganh}%';")
        for row in cursor:
            answer = f'Mã ngành {row[1]} là {row[0]}'
    except:
        answer = random_Other_Answer()
    return answer


def read_Contact_point_Dept(conn, campus_name):
    print("Read")
    answer = ""
    cursor = conn.cursor()
    try:
        cursor.execute(f"select Phong,SDT from contact_point_dept where Phong LIKE N'%{campus_name}%';")
        nums = 0
        for row in cursor:
            nums += 1
            answer = f'Số điện thoại {row[0]} là {row[1]}'
    except:
        answer = random_Other_Answer()
    return answer, nums


def read_Planned_Figure(conn, major_name, year):
    print("Read")
    answer = ""
    cursor = conn.cursor()
    try:
        cursor.execute(
            f"select major_name, number from planned_figure where major_name LIKE N'%{major_name}%' AND year LIKE {year};")
        for row in cursor:
            answer = f'Chỉ tiêu của ngành {row[0]} trong {year} là {row[1]}'
    except:
        answer = random_Other_Answer()
    return answer


def read_Contact_point_Teacher(conn, teacher_name, dept_name):
    print("Read")
    answer = ""
    teacher_name_tmp = teacher_name.replace("thầy ", "")
    teacher_name_tmp = teacher_name_tmp.replace("cô ", "")
    teacher_name_tmp = teacher_name_tmp.replace("thây ", "")
    teacher_name_tmp = teacher_name_tmp.replace("thày ", "")
    teacher_name_tmp = teacher_name_tmp.replace("co ", "")
    teacher_name_tmp = teacher_name_tmp.replace("Thầy ", "")
    teacher_name_tmp = teacher_name_tmp.replace("Cô ", "")
    teacher_name_tmp = teacher_name_tmp.replace("Thây ", "")
    teacher_name_tmp = teacher_name_tmp.replace("Thày ", "")
    teacher_name_tmp = teacher_name_tmp.replace("Co ", "")

    cursor = conn.cursor()
    teacher_name_answer = ""
    if (dept_name is None):
        if len(teacher_name_tmp.split()) == 1:
            try:
                cursor.execute(
                    f"select HoVaTen,SDT,Email from contact_point_teacher where Ten LIKE N'{teacher_name_tmp}';")
                nums = 0
                for row in cursor:
                    nums = nums + 1
                    teacher_name_answer += row[0] + ", "
                    answer = f'Số điện thoại của {teacher_name} là {row[1]} và email là {row[2]}'
            except:
                answer = random_Other_Answer()
        else:
            try:
                cursor.execute(
                    f"select SDT,Email from contact_point_teacher where HoVaTen LIKE N'%{teacher_name_tmp}';")
                nums = 0
                for row in cursor:
                    nums = nums + 1
                    answer = f'Số điện thoại của {teacher_name} là {row[0]} và email là {row[1]}'
            except:
                answer = random_Other_Answer()

    else:
        try:
            cursor.execute(
                f"select SDT,Email,BoPhan from contact_point_teacher where HoVaTen LIKE N'%{teacher_name_tmp}' AND BoPhan LIKE N'%{dept_name}%';")
            nums = 0
            for row in cursor:
                nums = nums + 1
                answer = f'Số điện thoại của {teacher_name} ở {row[2]} là {row[0]} và email là {row[1]}'
        except:
            answer = random_Other_Answer()
    return answer, nums, teacher_name_answer


def read_Major_Fee(conn, major_name):
    cursor = conn.cursor()
    answer = ""
    try:
        cursor.execute(
            f"select description,major_name from major_fee where major_name LIKE N'%{major_name}%';")
        nums = 0
        for row in cursor:
            nums = nums + 1
            answer = f'Thông tin về học phí ngành {row[1]} như sau: {row[0]}'
    except:
        answer = random_Other_Answer()
    return answer


def read_Scholar_Value(conn, scholar_name):
    cursor = conn.cursor()
    answer = ""
    try:
        cursor.execute(
            f"select scholar_name, value from scholar_value where scholar_name LIKE N'%{scholar_name}%';")
        nums = 0
        for row in cursor:
            nums = nums + 1
            answer = f'Thông tin về giá trị {row[0]} như sau: {row[1]}'
    except:
        answer = random_Other_Answer()

    return answer


def read_Scholar_Type(conn, scholar_name):
    cursor = conn.cursor()
    answer = ""
    try:
        cursor.execute(
            f"select scholar_name, types from scholar_type where scholar_name LIKE N'%{scholar_name}%';")
        nums = 0
        for row in cursor:
            nums = nums + 1
            answer = f'Thông tin về {row[0]} như sau: {row[1]}'
    except:
        answer = random_Other_Answer()
    return answer


def read_Scholar_Type_No_name():
    answer = "Hiện tại khoa đang áp dụng chính sách cho 4 loại học bổng: học bổng ngắn hạn, học bổng dài hạn," \
             " học bổng liên kết, học bổng dành cho SV có thành tích cao trong nghiên cứu khoa học, " \
             "Học bổng dành cho SV có thành tích đặc biệt xuất sắc. Bạn quan tâm đến loại nào không ạ? "
    return answer


def read_Credit_Fee(conn, major_name):
    cursor = conn.cursor()
    answer = ""
    try:
        cursor.execute(
            f"select description,major_name from credit_fee where major_name LIKE N'%{major_name}%';")
        nums = 0
        for row in cursor:
            nums = nums + 1
            answer = f'Thông tin về học phí (tín chỉ) ngành {row[1]} như sau: {row[0]}'
    except:
        answer = random_Other_Answer()
    return answer


def read_Major_Description(conn, major_name):
    cursor = conn.cursor()
    answer = ""
    try:
        cursor.execute(
            f"select description,major_name from major_description where major_name LIKE N'%{major_name}%';")
        nums = 0
        for row in cursor:
            nums = nums + 1
            answer = f'Thông tin chung về ngành {row[1]} như sau: {row[0]}'
    except:
        answer = random_Other_Answer()
    return answer


def read_School_Location():
    answer = "Khoa hiện tại có trụ sở chính tại Nhà C, Làng SV Hacinco, số 79 Ngụy Như Kon Tum, " \
             "Thanh Xuân, Hà Nội. Và một trụ sở nữa tại nhà G7,G8 số 144 Xuân Thủy, Cầu Giấy, Hà Nội nhé."
    return answer


def read_Admission_Type():
    answer = "Các chương trình do Đại học Quốc gia Hà Nội cấp bằng tại Khoa Quốc tế xét tuyển theo 5 phương thức:" \
             "(1) Xét tuyển thẳng theo quy định của Bộ GD-ĐT và của ĐHQGHN." \
             "(2) Kết quả thi tốt nghiệp THPT năm 2020" \
             "(3) Chứng chỉ quốc tế A-level của Trung tâm Khảo thí Đại học Cambridge, Anh" \
             "(4) Kết quả kỳ thi chuẩn hóa SAT (Scholastic Assessment Test, Hoa Kỳ)" \
             "(5) Chứng chỉ tiếng Anh quốc tế: IELTS, TOEFL PBT, TOEFL iBT" \
             "Nếu đăng ký xét tuyển bằng điểm thi THPT năm 2020, thí sinh cần phải đăng kí tối thiểu 1 Nguyện vọng vào ngành đào tạo do ĐHQGHN cấp bằng tại Khoa Quốc tế trong phiếu đăng kí xét tuyển đại học theo hướng dẫn của Bộ GD&ĐT." \
             "Nếu đăng ký xét tuyển thẳng hoặc theo phương thức khác, thí sinh chuẩn bị bộ hồ sơ nộp trực tiếp cho Khoa Quốc tế theo hướng dẫn tại: https://student.isvnu.vn/news-huong-dan-xet-tuyen-thang-uu-tien-xet-tuyen-va-xet-tuyen-theo-phuong-thuc-khac-vao-khoa-quoc-te-nam-2020.html"
    return answer


def read_Trans_Opportunity():
    answer = "Các trường ĐH nước ngoài nào công nhận chuyển tiếp cho các chương trình đào tạo tại Khoa Quốc tế - ĐHQGHN bao gồm:" \
             "(1)Trường ĐH Missouri và ĐH Keuka (Hoa Kỳ) " \
             "(2)Trường ĐH Herriot Watt và Huddersfield (Anh) " \
             "(3)Trường Đại học Macquarie và Đại học Canberra (Úc) " \
             "(4)Trường Đại học Lunghwa, ĐH Chien Kua (Đài Loan), Đại học HELP Malaysia và Đại học Kỹ thuật Năng lượng Mát-xcơ-va (MPEI) " \
             "Để xem sơ đồ chuyển tiếp của các chương trình đào tạo tại Khoa tại đây: http://chuyentiep.khoaquocte.vn"
    return answer


def read_Direct_Offer():
    answer = " Để biết rõ hơn thông tin về quy định xét tuyển thẳng của Khoa, bạn xem chi tiết tại đây: https://student.isvnu.vn/news-huong-dan-xet-tuyen-thang-uu-tien-xet-tuyen-va-xet-tuyen-theo-phuong-thuc-khac-vao-khoa-quoc-te-nam-2020.html"
    return answer


def read_Establishment_Time():
    answer = "Khoa Quốc tế tiền thân là Khoa Việt-Nga được thành lập vào 24/07/2002."
    return answer


def read_School_Organization():
    answer = "Khoa hiện có 5 phòng chức năng: Phòng Tổ chức-Hành chính, Phòng Đào tạo, Phòng Khoa học công nghệ và Hợp tác phát triển, Phòng Kế hoạch Tài chính, Phòng Công tác học sinh sinh viên; 3 bộ môn là: Bộ môn Khoa học tự nhiên và Công nghệ, Bộ môn Khoa học xã hội, Kinh tế và Quản lý, Bộ môn Đào tạo dự bị, 4 trung tâm và phòng nghiên cứu trực thuộc là: Trung tâm Đảm bảo chất lượng Khảo thí, Trung tâm Đào tạo và Chuyển giao tri thức, Phòng nghiên cứu Data science and Optimization of complex systems và phòng LAB nghiên cứu."
    return answer


def read_School_Mission():
    answer = "Sứ mệnh của Khoa là: Đào tạo, nghiên cứu khoa học, chuyển giao công nghệ định hướng theo các tiêu chuẩn kiểm định quốc tế dựa trên nền tảng khoa học cơ bản, khoa học ứng dụng, khoa học liên ngành và chuyển giao tri thức, góp phần cung cấp nguồn nhân lực và các sản phẩm khoa học - công nghệ chất lượng cao, đạt chuẩn quốc tế phục vụ sự nghiệp phát triển đất nước."
    return answer


def read_Major_training_time(conn, major_name):
    cursor = conn.cursor()
    answer = ""
    try:
        cursor.execute(
            f"select description,major_name from major_training_time where major_name LIKE N'%{major_name}%';")
        nums = 0
        for row in cursor:
            nums = nums + 1
            answer = f'Thông tin về thời gian đào tạo ngành {row[1]}: {row[0]}'
    except:
        answer = random_Other_Answer()
    return answer


def read_Issued_By(conn, major_name):
    cursor = conn.cursor()
    answer = ""
    try:
        cursor.execute(
            f"select description,major_name from issued_by where major_name LIKE N'%{major_name}%';")
        nums = 0
        for row in cursor:
            nums = nums + 1
            answer = f'Thông tin về việc cấp bằng của ngành {row[1]}: {row[0]}'
    except:
        answer = random_Other_Answer()

    return answer


def read_Mode_of_Study(conn, major_mode):
    cursor = conn.cursor()
    answer = ""
    try:
        cursor.execute(
            f"select description,major_name from major_description where major_name LIKE N'%{major_mode}%';")
        nums = 0
        for row in cursor:
            nums = nums + 1
            answer = f'Thông tin chung về chương trình {row[1]} như sau: {row[0]}'
    except:
        answer = random_Other_Answer()
    return answer


def read_Job_Opportunities(conn, major_name):
    cursor = conn.cursor()
    answer = ""
    try:
        cursor.execute(
            f"select description,major_name from career_opportunity_major where major_name LIKE N'%{major_name}%';")
        nums = 0
        for row in cursor:
            nums = nums + 1
            answer = f'Cơ hội nghề nghiệp của ngành {row[1]}: {row[0]}'
    except:
        answer = random_Other_Answer()
    return answer


def read_Enroll_Docs(conn, doc_name):
    cursor = conn.cursor()
    answer = ""
    try:
        cursor.execute(
            f"select MoTa,Doc_Name from enroll_document where Doc_Name LIKE N'%{doc_name}%';")
        nums = 0
        for row in cursor:
            nums = nums + 1
            answer = f'Về {row[1]}: {row[0]}'
    except:
        answer = random_Other_Answer()
    return answer


def read_NoCredit_Major(conn, major_name):
    cursor = conn.cursor()
    answer = ""
    try:
        cursor.execute(
            f"select major_name, description from nocredit_major where major_name LIKE N'%{major_name}%';")
        nums = 0
        for row in cursor:
            nums = nums + 1
            answer = f'Thông tin khung đào tạo của ngành {row[0]} là: {row[1]}'
    except:
        answer = random_Other_Answer()
    return answer


def random_MajorName_Answer(intent):
    value = random.randint(0, 3)
    if value == 0:
        answer = "Bạn muốn hỏi " + intent + " của ngành nào ?"
    if value == 1:
        answer = "Bạn đang quan tâm tới " + intent + " của ngành nào vậy ?"
    if value == 2:
        answer = "Bạn muốn biết thông tin " + intent + " của ngành nào nhỉ ?"
    if value == 3:
        answer = "Bạn muốn hỏi thông tin " + intent + " của ngành nào ạ ?"
    return answer

def random_DocsName_Answer():
    answer = f'Giấy tờ nhập học bao gồm: CV, học bạ cấp ba, Giấy chuyển nghĩa vụ quân sự, Sổ đoàn, Giấy chứng nhận kết quả thi, Giấy báo nhập học, ' \
                 f'Giấy báo trúng tuyển, Giấy chứng nhận tốt nghiệp THPT.'
    return answer
def random_Scholar_Answer(intent):
    value = random.randint(0, 3)
    if value == 0:
        answer = "Bạn muốn hỏi " + intent + " nào ?"
    if value == 1:
        answer = "Bạn đang quan tâm tới " + intent + " nào vậy ?"
    if value == 2:
        answer = "Bạn muốn biết thông tin " + intent + " nào nhỉ ?"
    if value == 3:
        answer = "Bạn muốn hỏi thông tin " + intent + " nào ạ ?"
    return answer


def random_Program_Answer(intent):
    value = random.randint(0, 3)
    if value == 0:
        answer = "Bạn muốn hỏi " + intent + " của chương trình nào ?"
    if value == 1:
        answer = "Bạn đang quan tâm tới " + intent + " của chương trình nào vậy ?"
    if value == 2:
        answer = "Bạn muốn biết thông tin " + intent + " của chương trình nào nhỉ ?"
    if value == 3:
        answer = "Bạn muốn hỏi thông tin " + intent + " của chương trình nào ạ ?"
    return answer


def random_not_found_major(major_name):
    value = random.randint(0, 2)
    if value == 0:
        answer = "Ngành " + major_name + " chưa cập nhật hoặc không nằm trong chương trình đào tạo của trường."
    if value == 1:
        answer = "Ngành " + major_name + " chưa cập nhật hoặc không nằm trong khung đào tạo của trường ạ!"
    if value == 2:
        answer = "Rất tiếc ngành bạn hỏi không thuộc phạm vi trường đào tạo, bạn muốn hỏi ngành nào khác không ?"

    return answer


def random_not_found_scholar(scholar):
    value = random.randint(0, 2)
    if value == 0:
        answer = "" + scholar + " không nằm trong danh sách học bổng của trường."
    if value == 1:
        answer = "" + scholar + " không nằm danh sách học bổng của trường ạ."
    if value == 2:
        answer = "Học bổng bạn hỏi không thuộc danh sách của trường, bạn muốn hỏi học bổng nào khác không ?"

    return answer


def random_KYear_Answer(intent):
    value = random.randint(0, 3)
    if value == 0:
        answer = "Bạn muốn hỏi " + intent + " của năm nào ?"
    if value == 1:
        answer = "Bạn đang quan tâm tới " + intent + " của năm nào vậy ?"
    if value == 2:
        answer = "Bạn muốn biết thông tin " + intent + " của năm nào nhỉ ?"
    if value == 3:
        answer = "Bạn muốn hỏi thông tin " + intent + " của năm nào ạ ?"
    return answer


def random_TeacherName_Answer(teacher_name, nums, teachers):
    value = random.randint(0, 3)
    if value == 0:
        answer = "Hiện khoa đang có " + str(
            nums) + " " + teacher_name + " là " + teachers + "Bạn muốn hỏi thông tin của " + teacher_name + " nào ạ ?"
    if value == 1:
        answer = "Hiện khoa đang có " + str(
            nums) + " " + teacher_name + " là " + teachers + "Bạn muốn biết thông tin " + teacher_name + " nào nhỉ ?"
    if value == 2:
        answer = "Hiện khoa đang có " + str(
            nums) + " " + teacher_name + " là " + teachers + "Bạn cho mình biết tên đầy đủ của " + teacher_name + " nhé"
    if value == 3:
        answer = "Hiện khoa đang có " + str(
            nums) + " " + teacher_name + " là " + teachers + "Bạn muốn liên hệ với " + teacher_name + " nào nhỉ ?"
    return answer


def random_Username_Answer():
    value = random.randint(0, 4)
    if value == 0:
        answer = "Tên bạn là gì ?"
    if value == 1:
        answer = "Bạn cho mình biết tên nhé!"
    if value == 2:
        answer = "Bạn để lại tên để tư vấn viên gọi nhé!"
    if value == 3:
        answer = "Tên của bạn là gì vậy ạ ?"
    if value == 4:
        answer = "Sorry, bạn cho mình biết tên bạn được không?, bên mình sẽ phản hồi lại bạn sau ạ!"
    return answer


def random_PhoneNumber_Answer():
    value = random.randint(0, 4)
    if value == 0:
        answer = "Vậy khoa có thể gọi cho em theo số điện thoại nào ?"
    if value == 1:
        answer = "Em dùng số điện thoại nào nhỉ ?"
    if value == 2:
        answer = "Số điện thoại của em là gì ?"
    if value == 3:
        answer = "Khoa sẽ liên lạc với em sau qua số điện thoại nào được nhỉ ?"
    if value == 4:
        answer = "Em để lại số điện thoại để tư vấn viên gọi nhé!"
    return answer


def random_Greeting_Answer():
    value = random.randint(0, 2)
    if value == 0:
        answer = "Chào bạn! Mình là iBOT đây ạ, mình được sinh ra để hỗ trợ bạn về các thông tin: Cơ cấu tổ chức, học phí, điểm chuẩn các ngành, học bổng, nghiên cứu khoa học,... bạn cần hỗ trợ gì ạ!"
    if value == 1:
        answer = "Chào bạn! Mình là iBOT thuộc khoa Quốc tế, mình sinh ra để hỗ trợ bạn về các thông tin: Cơ cấu tổ chức, học phí, điểm chuẩn các ngành, học bổng, nghiên cứu khoa học,... bạn muốn hỏi gì nào?"
    if value == 2:
        answer = "Hi bạn! Mình là iBOT thuộc khoa Quốc tế, mình có sứ mệnh hỗ trợ bạn về các thông tin: Cơ cấu tổ chức, học phí, điểm chuẩn các ngành, học bổng, nghiên cứu khoa học,... bạn cần mình giúp gì nào :)"

    return answer


def random_Bye_Answer():
    value = random.randint(0, 6)
    if value == 0:
        answer = "Tạm biệt bạn, chúc bạn sức khỏe!"
    if value == 1:
        answer = "Bye!"
    if value == 2:
        answer = "Cảm ơn bạn đã ghé thăm!"
    if value == 3:
        answer = "Tạm biệt bạn!"
    if value == 4:
        answer = "Bye bye!"
    if value == 5:
        answer = "Tạm biệt bạn, cảm ơn bạn đã ghé thăm"
    if value == 6:
        answer = "OK, chúc bạn sức khỏe nhé!"
    return answer


def random_Agree_Answer():
    value = random.randint(0, 2)
    if value == 0:
        answer = "Oh, cảm ơn bạn cùng quan điểm!"
    if value == 1:
        answer = "Vâng, cảm ơn bạn"
    if value == 2:
        answer = "Dạ vâng, bạn cần hỏi gì nữa không?"
    return answer


def random_Other_Answer():
    value = random.randint(0, 3)
    if value == 0:
        answer = "Xin lỗi ý của bạn là gì?"
    if value == 1:
        answer = "Xin lỗi. Bạn có thể nhắc lại ý định của bạn được không?"
    if value == 2:
        answer = "Xin lỗi. Tôi không hiểu câu nói của bạn."
    if value == 3:
        answer = "Tôi không hiểu ý bạn lắm. Bạn có thể nhắc lại ý định của bạn được không?"
    return answer


def random_Out_Area_Answer():
    value = random.randint(0, 2)
    if value == 0:
        answer = "Xin lỗi. Câu này ngoài chuyên môn của mình?"
    if value == 1:
        answer = "Xin lỗi. Câu hỏi này ngoài tầm hiểu biết của mình. Bạn liên lạc trực tiếp các thầy cô trong Khoa nhé!"
    if value == 2:
        answer = "Xin lỗi, mình chưa trả lời được câu hỏi của bạn, vui lòng đợi TVV trong giây lát"

    return answer


def random_Direct_Resquest_Username():
    value = random.randint(0, 5)
    if value == 0:
        answer = "Tên em là gì?"
    if value == 1:
        answer = "Em cho mình biết tên nhé!"
    if value == 2:
        answer = "Em để lại tên để tư vấn viên gọi nhé."
    return answer


def random_Direct_Resquest_PhoneNumber():
    value = random.randint(0, 2)
    if value == 0:
        answer = "Vậy Khoa có thể gọi cho em theo số điện thoại nào?"
    if value == 1:
        answer = "Em dùng số điện thoại nào nhỉ?"
    if value == 2:
        answer = "Em để lại số điện thoại để tư vấn viên gọi nhé."
    return answer


def random_Direct_Resquest_Answer(phone_number):
    value = random.randint(0, 2)
    if value == 0:
        answer = "Ok cảm ơn bạn, chúng tôi sẽ liên lạc với bạn qua số điện thoại " + phone_number + " trong thời gian sớm nhất ạ."
    if value == 1:
        answer = "Dạ vâng, tư vấn viên của chúng tôi sẽ gọi cho bạn qua số " + phone_number + " sau nhé!"
    if value == 2:
        answer = "Bạn chờ điện thoại tư vấn trực tiếp, chúng tôi sẽ liên hệ với bạn qua số " + phone_number + " nhé!"
    return answer


def get_turn(turn_Major_Name, turn_datetime, turn_Teacher_Name, turn_Campus_Name, turn_Dept_Name, turn_Major_Mode,
             turn_Docs_Name, turn_Scholar_Name, major_name, year, teacher_name, campus_name, dept_name, major_mode,
             doc_name, scholar_name):
    if major_name is None:
        turn_Major_Name += 1
    if year is None:
        turn_datetime += 1
    if teacher_name is None:
        turn_Teacher_Name += 1
    if campus_name is None:
        turn_Campus_Name += 1
    if dept_name is None:
        turn_Dept_Name += 1
    if major_mode is None:
        turn_Major_Mode += 1
    if doc_name is None:
        turn_Docs_Name += 1
    if scholar_name is None:
        turn_Scholar_Name += 1
    return turn_Major_Name, turn_datetime, turn_Teacher_Name, turn_Campus_Name, turn_Dept_Name, turn_Major_Mode, turn_Docs_Name, turn_Scholar_Name

