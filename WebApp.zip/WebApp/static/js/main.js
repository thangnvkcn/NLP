const msgerForm = get(".msger-inputarea");
const msgerInput = get(".msger-input");
const msgerChat = get(".msger-chat");
//const debug = get(".debug");

// Icons made by Freepik from www.flaticon.com
const BOT_IMG = "https://is2-ssl.mzstatic.com/image/thumb/Purple128/v4/85/67/b1/8567b1e5-70a0-3e16-f67d-d13892d82f19/source/256x256bb.jpg";
const PERSON_IMG = "https://image.flaticon.com/icons/svg/145/145867.svg";
const BOT_NAME = "BOT";
const PERSON_NAME = "Guest";

window.onload = window.localStorage.clear();

function appendMessage(name, img, side, text) {
  //   Simple solution for small apps
  const msgHTML = `
    <div class="msg ${side}-msg">
      <div class="msg-img" style="background-image: url(${img})"></div>
      <div class="msg-bubble">
        <div class="msg-info">
          <div class="msg-info-name">${name}</div>
          <div class="msg-info-time">${formatDate(new Date())}</div>
        </div>
        <div class="msg-text">${text}</div>
      </div>
    </div>
  `;

  msgerChat.insertAdjacentHTML("beforeend", msgHTML);
  msgerChat.scrollTop += 500;
}

//function appendDebug(msg ="",intent_45 = "", ner="",response="") {
//  //   Simple solution for small apps
//  const msgHTML = `
//    <div class="card bg-light mb-3" style="max-width: 100%;">
//        <div class="card-header">Thông tin</div>
//        <div class="card-body">
//          <p class="card-text">
//              <strong>Message: </strong>${msg}
//          </p>
//          <p class="card-text">
//              <strong>Intent: </strong>${intent_45}
//          </p>
//          <p class="card-text">
//              <strong>NER: </strong>${ner}
//          </p>
//          <p class="card-text">
//              <strong>Response: </strong>${response}
//          </p>
//        </div>
//    </div>
//  `;
//
//  debug.insertAdjacentHTML("beforeend", msgHTML);
//  msgerChat.scrollTop += 500;
//}
var num_send = 0;
var resp = null ;
msgerForm.addEventListener("submit", event => {
  event.preventDefault();

  const msgText = msgerInput.value;
  if (!msgText) return;
  appendMessage(PERSON_NAME, PERSON_IMG, "right", msgText);
  msgerInput.value = "";
  userSend(msgText);
  botResponse();
});
var ID = Date.now() + Math.random().toString().slice(2);
function userSend(text){
    var req = new XMLHttpRequest();
    req.open("POST", "/process", false);
    req.setRequestHeader("Content-Type", "application/json; charset=UTF-8");
    var rawText = text;
    var dict = {text: rawText, id:ID, num_send: num_send}
    req.send(JSON.stringify(dict));
    resp = JSON.parse(req.response).text_tagged;
    num_send = resp.num_send;
    num_send += 1;
}

function botResponse(){
  const intent_45 = resp.results_45;
  const text = resp.text
  const msgText = resp.answer !== "" ? resp.answer : "Xin l?i � c?a b?n l� g� ?!";
  appendMessage(BOT_NAME, BOT_IMG, "left", msgText);
}


// Utils
function get(selector, root = document) {
  return root.querySelector(selector);
}

function formatDate(date) {
  const h = "0" + date.getHours();
  const m = "0" + date.getMinutes();

  return `${h.slice(-2)}:${m.slice(-2)}`;
}

function random(min, max) {
  return Math.floor(Math.random() * (max - min) + min);
}

